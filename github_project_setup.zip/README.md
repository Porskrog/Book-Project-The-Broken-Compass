# GitHub Project Setup – Quick Start

## 1️⃣ Upload
Upload hele `.github`-mappen til dit repo (via GitHub → Add file → Upload files).

## 2️⃣ Importér labels
Kør:
```bash
gh label import -f .github/labels.yml
```

## 3️⃣ Test issue templates
Gå til **Issues → New issue** → Vælg "Chapter card", "Feature card" eller "Task card".

## 4️⃣ Opret Project (Table)
1. Klik **Projects → New project → Table**
2. Tilføj felter: Stage, Owner, Target date, Milestone
3. Lav views: "This Week", "At Risk", "Roadmap", "Writing Flow"
4. Tilføj dine issues til projektet og milestones.

Alt klar til brug 🚀
